package com.room.sample.servlet;
 
import java.io.IOException;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import com.room.sample.view.Login;
 
public class LoginCustomerServlet extends HttpServlet{
 
    private static final long serialVersionUID = 1L;
    public void doPost(HttpServletRequest request, HttpServletResponse response){
        System.out.println("----- LoginCustomerServlet -----");
        try {
        // Get the customer value submitted from Customer.jsp page through HttpServletRequest object
            String name=request.getParameter("name");
            String address=request.getParameter("address");
            System.out.println(name);
            System.out.println(address);
             
            //Set the Customer values into Customer Bean or POJO(Plain Old Java Object) class
            Login customer=new Login();
            customer.setName(name);
            customer.setAddress(address);
            RequestDispatcher dispatcher;
            if(name == "deraviyam" && address=="deraviyam")
			{
			dispatcher=request.getRequestDispatcher("/Customer.jsp");
			}
             else{
			 dispatcher=request.getRequestDispatcher("/error.jsp");
			 }
            
            //Set the customer instance into request.Then only the customer object 
            //will be available in the Welcome.jsp page
            request.setAttribute("custt",customer);
            dispatcher.forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
         
    }
 
}