package com.room.sample.view;
 
import java.io.Serializable;
 
public class Enquiry implements Serializable{
 
    private static final long serialVersionUID = 1L;
    private String emailid;
    private String comments;
    
    public String getEmailid() {
        return emailid;
    }
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }
    
    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
        this.comments = comments;
    }
    

     
}