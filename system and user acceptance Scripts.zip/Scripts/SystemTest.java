package packagetest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SystemTest {

	WebDriver driver;
	String hometitle="HillValley Homepage";
	
	@BeforeMethod
	public void browsercall()
	{
		//driver=new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	@Test(priority=0)
	public void hompagenavg()
	{
		
		
		driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.findElement(By.xpath("//img[@src='needhelp.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h1[text()='Help']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		driver.findElement(By.xpath("//img[@src='enquiry.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h1[text()='SEND US YOUR ENQUIRY']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Home']")).click();	
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.close();
	}
	
	@Test(priority=1)
	public void sendenquiry()
	{   
	    driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
	    driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
		driver.findElement(By.xpath("//img[@src='enquiry.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h1[text()='SEND US YOUR ENQUIRY']")).isDisplayed();
		driver.findElement(By.name("emailid")).sendKeys("deraviyam.jacob@gmail.com");
		driver.findElement(By.name("comments")).sendKeys("What's the two year membership cost for purple plan");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h1[text()='Thank You']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Home']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Enquiry']")).isDisplayed();
		driver.close();
		
	}
	
	@Test(priority=2)
	public void enquirylinkcheck()
	{   
	    driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
        driver.manage().window().maximize();
	    driver.findElement(By.xpath("//img[@src='enquiry.jpg']")).click();
	    driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//h1[text()='SEND US YOUR ENQUIRY']")).isDisplayed();
	    
	    driver.findElement(By.name("emailid")).sendKeys("deraviyam.jacob@gmail.com");
		driver.findElement(By.name("comments")).sendKeys("What's the two year membership cost for purple plan");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//a[text()='Enquiry']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//h1[text()='SEND US YOUR ENQUIRY']")).isDisplayed();
		driver.findElement(By.name("emailid")).sendKeys("arunkumar@gmail.com");
		driver.findElement(By.name("comments")).sendKeys("What's the two year membership cost for purple plan");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[text()='Home']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.close();
	}
	
	@Test(priority=3)
	public void Loginnegativetest()
	{		
		driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.findElement(By.xpath("//img[@src='login.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.name("username")).isDisplayed();
		driver.findElement(By.name("userpassword")).isDisplayed();
		driver.findElement(By.name("username")).sendKeys("deraviyam");
		driver.findElement(By.name("userpassword")).sendKeys("derviyam");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h1[contains(text(),'Invalid username')]")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Login again!']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.close();
	}
	
	
	
	
}
