package packagetest;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class UserAcceptanceTest {

	WebDriver driver;
	String hometitle="HillValley Homepage";
	String resortdetails="Resortlist";
	
	@BeforeMethod
	public void browsercall()
	{
		//driver=new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	
	
	@Test(priority=0)
	public void Loginpositivetest()
	{  
		driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.findElement(By.xpath("//img[@src='login.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.name("username")).isDisplayed();
		driver.findElement(By.name("userpassword")).isDisplayed();
		driver.findElement(By.name("username")).sendKeys("deraviyam");
		driver.findElement(By.name("userpassword")).sendKeys("deraviyam");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//b[text()='Logout']")).isDisplayed();
	    driver.close();
		
	}
	
	@Test(priority=1)
	public void tabsnavigate()
	{   
		driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.findElement(By.xpath("//img[@src='login.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.name("username")).isDisplayed();
		driver.findElement(By.name("userpassword")).isDisplayed();
		driver.findElement(By.name("username")).sendKeys("deraviyam");
		driver.findElement(By.name("userpassword")).sendKeys("deraviyam");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//b[text()='Logout']")).isDisplayed();
	    driver.findElement(By.xpath("//a[text()='Membership']")).click();
        driver.findElement(By.xpath("//input[@type='submit']")).isDisplayed();
        driver.findElement(By.xpath("//a[text()='Plans']")).click();
        driver.findElement(By.xpath("//h2[text()='Membership Plans']")).isDisplayed();
        driver.findElement(By.xpath("//a[text()='Resorts']")).click();
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
        Assert.assertEquals(resortdetails, driver.getTitle());
        driver.findElement(By.xpath("//img[@src='resortlistbackbutton.jpg']")).click();
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//b[text()='Logout']")).isDisplayed();
		driver.close();
	}
	
	@Test(priority=2)
	public void customerdetails()
	{   
		driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.findElement(By.xpath("//img[@src='login.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.name("username")).isDisplayed();
		driver.findElement(By.name("userpassword")).isDisplayed();
		driver.findElement(By.name("username")).sendKeys("deraviyam");
		driver.findElement(By.name("userpassword")).sendKeys("deraviyam");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//b[text()='Logout']")).isDisplayed();
	    driver.findElement(By.xpath("//a[text()='Membership']")).click();
	    driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//input[@type='submit']")).isDisplayed();
        driver.findElement(By.name("name")).sendKeys("Deraviyam");
        driver.findElement(By.name("address")).sendKeys("Chennai");
        driver.findElement(By.name("mobile")).sendKeys("9885654789");
        driver.findElement(By.name("emailid")).sendKeys("deraviyam.jacob@gmail.com");
        driver.findElement(By.name("dob")).sendKeys("16Jan1990");
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//td[contains(text(),'Welcome')]")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Back']")).isDisplayed();
		driver.findElement(By.xpath("//a[text()='Back']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.close();
	}
	
	@Test(priority=3)
	public void logout()
	{   
		driver.get("http://localhost:8080/HillValleyClub-0.0.1-SNAPSHOT/HomePage.jsp");
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		Assert.assertEquals(hometitle, driver.getTitle());
		driver.findElement(By.xpath("//img[@src='login.jpg']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.name("username")).isDisplayed();
		driver.findElement(By.name("userpassword")).isDisplayed();
		driver.findElement(By.name("username")).sendKeys("deraviyam");
		driver.findElement(By.name("userpassword")).sendKeys("deraviyam");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//b[text()='Logout']")).isDisplayed();
	    driver.findElement(By.xpath("//a[text()='Plans']")).click();
        driver.findElement(By.xpath("//h2[text()='Membership Plans']")).isDisplayed();
        driver.findElement(By.xpath("//b[text()='Logout']")).click();
        driver.findElement(By.name("username")).isDisplayed();
		driver.findElement(By.name("userpassword")).isDisplayed();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[text()='Home']")).click();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		Assert.assertEquals(hometitle, driver.getTitle());
	    driver.close();
	    
	}
	
	
}
